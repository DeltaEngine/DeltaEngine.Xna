namespace $safeprojectname$
{
	public enum BlockType
	{
		None,
		Gold,
		GroundBrick,
		PlatformBrick,
		PlatformTop,
		LevelBorder
	}
}
