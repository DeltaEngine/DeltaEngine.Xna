namespace $safeprojectname$
{
	public enum $safeprojectname$RenderLayer
	{
		Background = 0,
		Rockets = 1,
		Player = 3,
		$safeprojectname$ = 5,
		UserInterface = 6
	}
}