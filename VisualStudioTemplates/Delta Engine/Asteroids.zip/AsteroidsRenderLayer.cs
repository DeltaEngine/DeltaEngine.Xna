namespace $safeprojectname$
{
	public enum AsteroidsRenderLayer
	{
		Background = 0,
		Rockets = 1,
		Player = 3,
		Asteroids = 5,
		UserInterface = 6
	}
}