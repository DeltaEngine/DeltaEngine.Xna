namespace $safeprojectname$.Screens
{
	/*TODO
	public partial class MainMenu : BaseGameScreen
	{
		public MainMenu()
		{
			this.InitializeControls();
			this.NewGameButton.Clicked += delegate
			{
				new CharacterMenu().Open();
			};
			this.LoadButton.Clicked += delegate
			{
				new LoadMenu().Open();
			};
			this.CreditsButton.Clicked += delegate
			{
				new Credits().Open();
				Log.Info("Halooo blaaaaaaaa");
			};
		}
	}
	 */
}