namespace $safeprojectname$.Screens
{
	/*TODO
	public partial class LoadMenu : BaseGameScreen
	{
		public LoadMenu()
		{
				this.InitializeControls();

				BackButton.Clicked += delegate
				{
					Close();
				};
		}
	}
	 */
}
