namespace $safeprojectname$.Towers
{
	public enum AttackType
	{
		DirectShot,
		RadiusFull,
		CircleSector
	}
}