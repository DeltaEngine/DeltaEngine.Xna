namespace $safeprojectname$.Content
{
	public enum Xml
	{
		CreepProperties,
		TowerProperties,
		GroupProperties, 
		BossProperties,
		AvatarProperties, 
		N1C3AvatarSuperVillainDialogues
	}
}