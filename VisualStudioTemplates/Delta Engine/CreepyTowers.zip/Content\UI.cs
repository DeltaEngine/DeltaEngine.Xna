namespace $safeprojectname$.Content
{
	public enum UI
	{
		SceneIntroMenu,
		SceneMainMenu,
		SceneOptionsMenu,
		SceneCredits,
		GameHud,
		SceneChildsRoom,
		SceneBathroom,
		SceneLivingRoom
	}
}