namespace $safeprojectname$.Content
{
	public enum MainMenu
	{
		ButtonPlay,
		ButtonSettings, 
		ButtonCredits,
		ButtonQuit
	}
}
