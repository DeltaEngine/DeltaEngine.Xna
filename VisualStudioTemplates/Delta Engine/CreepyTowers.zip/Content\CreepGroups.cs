namespace $safeprojectname$.Content
{
	public enum CreepGroups
	{
		GroupCreeps
	}
}