namespace $safeprojectname$.Content
{
	public enum Cinematics
	{
		SuperVillainImage,
		SuperVillainSpeechPanelTop,
		SuperVillainTalk,
		AvatarImage,
		AvatarSpeechPanelBottom,
		AvatarTalk,
		Instructions
	}
}