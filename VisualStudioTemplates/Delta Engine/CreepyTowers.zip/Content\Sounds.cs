namespace $safeprojectname$.Content
{
	public enum Sounds
	{
		PressButton
	}
}