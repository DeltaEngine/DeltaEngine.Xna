namespace $safeprojectname$.Content
{
	public enum TowerSelectionPanel
	{
		PanelButton1,
		PanelButton2,
		PanelButton3,
		PanelButton4,
		PanelButton5,
		PanelButton6
	}
}
