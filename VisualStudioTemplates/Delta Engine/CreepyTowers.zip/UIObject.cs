using DeltaEngine.Datatypes;

namespace $safeprojectname$
{
	public class UIObject
	{
		public string Name
		{
			get;
			set;
		}

		public Point Position
		{
			get;
			set;
		}

		public Size ObjectSize
		{
			get;
			set;
		}
	}
}