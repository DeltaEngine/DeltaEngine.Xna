namespace $safeprojectname$
{
	public enum DefRenderLayer
	{
		Background = 0,
		Player = 3,
	}
}